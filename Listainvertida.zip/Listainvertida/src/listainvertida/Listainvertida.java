/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package listainvertida;

/**
 *
 * @author FRANKLIN
 */
public class Listainvertida {
    
  int datos;
    Listainvertida sigui;
 
    Listainvertida(int dato, Listainvertida sig)
    {
        this.datos = dato;
        this.sigui = sig;
    }

    
    public static void printList(Listainvertida head)
    {
        Listainvertida ptr = head;
        while (ptr != null)
        {
            System.out.print(ptr.datos + " sig dato ");
            ptr = ptr.sigui;
        }
 
        System.out.println("nulo");
    }
 
   
    public static Listainvertida reversa(Listainvertida head)
    {
            Listainvertida previous = null;
        Listainvertida current = head;
 
       
        while (current != null)
        {
          
            Listainvertida siguiente = current.sigui;
 
            current.sigui = previous;    
            previous = current;
            current = siguiente;
        }
 
        
        return previous;
    }
 
    public static void main(String[] args)
    {
       
        int[] keys = { 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16  };
 
        Listainvertida head = null;
        for (int i = keys.length - 1; i >= 0; i--) {
            head = new Listainvertida(keys[i], head);
        }
 
        head = reversa(head);
        printList(head);
    }
}



   